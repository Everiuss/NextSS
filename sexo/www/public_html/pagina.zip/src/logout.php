<?php
@session_start();
session_destroy();
header("Location: https://clatyhouse.000webhostapp.com/index.php");
?>