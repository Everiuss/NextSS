<?php	
	// Crear conexion
	$conn = mysqli_connect('localhost', 'id20497079_equipozoila', '}9t#/E&Tdc\!Dc|g', 'id20497079_clatyhouse_db');
	// Checa la conexion
	if (!$conn) {
	    die ("ERROR: no se ha podido establecer la conexión" . mysql_connect_error());
	}
?>